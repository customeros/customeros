DROP FUNCTION mq_clear;
DROP FUNCTION mq_clear_all;

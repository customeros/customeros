DROP INDEX job_emails;
DROP TABLE email_results;
DROP TABLE bulk_jobs;
DROP TYPE valid_status;
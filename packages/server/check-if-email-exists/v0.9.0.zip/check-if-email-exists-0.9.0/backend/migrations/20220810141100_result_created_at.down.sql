ALTER TABLE email_results
DROP COLUMN created_at;

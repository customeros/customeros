# Integration Tests

Files in this folder are Reacher backend's integration tests. They need the following to work:

-   a working internet connection.
